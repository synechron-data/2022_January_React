// // Application Level CSS / Global CSS
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import HelloComponent from './components/1_hello/HelloComponent';

// ReactDOM.render(
//   <React.StrictMode>
//     <HelloComponent />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// -------------------------------- Using Bootstrap
// npm i bootstrap bootstrap-icons

// Application Level CSS / Global CSS
// import 'bootstrap/dist/css/bootstrap.css';
// import 'bootstrap-icons/font/bootstrap-icons.css';
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';

// import HelloComponent from './components/1_hello/HelloComponent';

// ReactDOM.render(
//   <React.StrictMode>
//     <HelloComponent />
//   </React.StrictMode>,
//   document.getElementById('root')
// );

// // -------------------------------------------------- Multi Components
// import 'bootstrap/dist/css/bootstrap.css';
// import 'bootstrap-icons/font/bootstrap-icons.css';
// import './index.css';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';
// import ComponentOne from './components/2_multi-components/ComponentOne';
// import ComponentTwo from './components/2_multi-components/ComponentTwo';

// // ReactDOM.render(
// //   <React.StrictMode>
// //     <ComponentOne />
// //     <ComponentTwo />
// //   </React.StrictMode>,
// //   document.getElementById('root')
// // );

// ReactDOM.render(
//   <React.StrictMode>
//     <ComponentOne />
//   </React.StrictMode>,
//   document.getElementById('root1')
// );

// ReactDOM.render(
//   <React.StrictMode>
//     <ComponentTwo />
//   </React.StrictMode>,
//   document.getElementById('root2')
// );

// -------------------------------------------------- Using Root Component
import 'bootstrap/dist/css/bootstrap.css';
import 'bootstrap-icons/font/bootstrap-icons.css';
import './index.css';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';
import RootComponent from './components/root/RootComponent';

var d = ReactDOM.render(
  <React.StrictMode>
    <RootComponent />
  </React.StrictMode>,
  document.getElementById('root')
);

console.log(d);