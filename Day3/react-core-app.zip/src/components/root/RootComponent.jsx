import React from 'react';

import CrudAssignment from '../1_crud/CrudAssignment';
import ErrorHandler from '../common/ErrorHandler';
import AjaxComponent from '../2_ajax/AjaxComponent';
import StateHookDemo from '../3_hooks/StateHookDemo';
import EffectHookDemo from '../3_hooks/EffectHookDemo';
import EffectHookAjax from '../3_hooks/EffectHookAjax';
import SiblingCommunicationUsingContextAndHooks from '../3_hooks/SiblingCommunication';

const RootComponent = () => {
    return (
        <div className='container'>
            <ErrorHandler>
                {/* <CrudAssignment /> */}
                {/* <AjaxComponent /> */}
                {/* <StateHookDemo /> */}
                {/* <EffectHookDemo /> */}
                {/* <EffectHookAjax /> */}
                <SiblingCommunicationUsingContextAndHooks />
            </ErrorHandler>
        </div>
    );
};

export default RootComponent;