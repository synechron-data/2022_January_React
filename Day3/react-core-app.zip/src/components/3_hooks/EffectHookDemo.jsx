import React, { useEffect, useState } from 'react';

const EffectHookDemo = () => {
    const [flag, setFlag] = useState(false);
    const [person, setPerson] = useState({ fname: 'Manish', lname: 'Sharma' });

    // Without second parameter, useEffect behaves like ComponentDidUpdate()
    // useEffect(() => {
    //     console.log("useEffect is called....");
    //     setTimeout(() => {
    //         setPerson({ fname: 'Abhijeet', lname: 'Gole' });
    //     }, 5000);
    // });

    // With second parameter as empty array, useEffect behaves like ComponentDidMount()
    // useEffect(() => {
    //     console.log("useEffect is called....");
    //     setTimeout(() => {
    //         setPerson({ fname: 'Abhijeet', lname: 'Gole' });
    //     }, 5000);
    // }, []);

    // With second parameter as metioned below, useEffect will run whenever flag changes
    useEffect(() => {
        console.log("useEffect is called....");
        setTimeout(() => {
            setPerson({ fname: 'Abhijeet', lname: 'Gole' });
        }, 5000);
    }, [flag]);

    return (
        <div>
            <h3 className="text-primary">Firstname: {person.fname}</h3>
            <h3 className="text-primary">Lastname: {person.lname}</h3>
            <button className='btn btn-primary' onClick={(e) => { setFlag(!flag); }}>Click</button>
        </div>
    );
};

export default EffectHookDemo;