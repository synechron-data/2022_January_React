import React, { Component } from 'react';
import CounterContextProvider, { CounterContext } from '../../context/CounterContext';

class Counter extends Component {
    static contextType = CounterContext;

    constructor(props) {
        super(props);
        this._inc = this._inc.bind(this);
        this._dec = this._dec.bind(this);
    }

    _inc(e) {
        var [count, setCount] = this.context;
        setCount(count + 1);
    }

    _dec(e) {
        var [count, setCount] = this.context;
        setCount(count - 1);
    }

    render() {
        return (
            <React.Fragment>
                <div className="text-center">
                    <h3 className="text-info">Counter Component</h3>
                </div>
                <div className="row d-flex justify-content-center">
                    <div className="col-sm-4">
                        <input type="text" className="form-control" value={this.context[0]} readOnly />
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info w-100" onClick={this._inc}>+</button>
                    </div>
                    <div className="col-sm-1">
                        <button className="btn btn-info w-100" onClick={this._dec}>-</button>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}

class CounterSibling extends Component {
    static contextType = CounterContext;

    render() {
        return (
            <div className="text-center">
                <h3 className="text-info">Counter Sibling Component</h3>
                <h3>Current Count is: {this.context[0]} </h3>
            </div>
        );
    }
}

const SiblingCommunicationUsingContext = () => {
    return (
        <div className='mt-5'>
            <CounterContextProvider>
                <Counter />
                <hr />
                <CounterSibling />
            </CounterContextProvider>
        </div>
    );
};

export default SiblingCommunicationUsingContext;