import React, { Component } from 'react';
import PropTypes from 'prop-types';

class Counter extends Component {
    constructor(props) {
        super(props);
        this._clickCount = 0;
        this.state = { count: 0, flag: false };
        this._inc = this._inc.bind(this);
        this._dec = this._dec.bind(this);
        this.reset = this.reset.bind(this);
    }

    _manageClickCount(e) {
        this._clickCount += 1;
        if (this._clickCount > 9) {
            this.setState({ flag: true }, () => {
                this.props.onMax(this.state.flag);
            });
        }
    }

    _inc(e) {
        this.setState({ count: this.state.count + this.props.interval }, () => {
            this._manageClickCount(e);
        });
    }

    _dec(e) {
        this.setState({ count: this.state.count - this.props.interval }, () => {
            this._manageClickCount(e);
        });
    }

    reset(e) {
        this._clickCount = 0;
        this.setState({ count: 0, flag: false }, () => {
            this.props.onMax(this.state.flag);
        });
    }

    render() {
        return (
            <React.Fragment>
                <div className="text-center">
                    <h3 className="text-info">Counter Component</h3>
                </div>
                <div className="d-grid gap-2 mx-auto col-6">
                    <input type="text" className="form-control form-control-lg" value={this.state.count} readOnly />
                    <button className="btn btn-info" disabled={this.state.flag}
                        onClick={this._inc}
                        style={this._style}>
                        <span className='fs-4'>+</span>
                    </button>
                    <button className="btn btn-info" disabled={this.state.flag}
                        onClick={this._dec}
                        style={this._style}>
                        <span className='fs-4'>-</span>
                    </button>
                    <button className="btn btn-secondary" disabled={!this.state.flag}
                        style={!this.state.flag ? { cursor: 'not-allowed', pointerEvents: 'all' } : {}}
                        onClick={this.reset}>
                        <span className='fs-4'>Reset</span>
                    </button>
                </div>
            </React.Fragment >
        );
    }

    get _style() {
        return this.state.flag ? { cursor: 'not-allowed', pointerEvents: 'all' } : {};
    }

    static get defaultProps() {
        return {
            interval: 1
        };
    }

    static get propTypes() {
        return {
            interval: PropTypes.number
        };
    }
}

class CounterAssignment extends Component {
    constructor(props) {
        super(props);
        this.state = { message: "" };
        this._counterRef = React.createRef();
        this.p_reset = this.p_reset.bind(this);
        this.updateMessage = this.updateMessage.bind(this);
    }

    p_reset(e) {
        // console.log(this.refs.t1);          // Depricated

        // if (this.t1)
        //     console.log(this.t1);

        // if (this._counterRef.current)
        //     console.log(this._counterRef.current);

        if (this._counterRef.current)
            this._counterRef.current.reset();
    }

    updateMessage(flag) {
        if (flag)
            this.setState({ message: "Max Click Reached, please click reset button to restart" });
        else
            this.setState({ message: "" });
    }

    render() {
        return (
            <div>
                <h2 className="text-success text-center mt-5 mb-5">Calling Parent Method from Child Component</h2>

                {
                    this.state.message ?
                        <div className="alert alert-danger text-center">
                            <h4>
                                <i className="bi bi-info-square-fill"></i>
                            </h4>
                            <h4 className="alert-heading">{this.state.message}</h4>
                        </div>
                        :
                        null
                }

                <Counter interval={10} ref={this._counterRef} onMax={this.updateMessage} />

                <div className="d-grid gap-2 mx-auto col-6 mt-5">
                    <button className="btn btn-warning" onClick={this.p_reset}>
                        <span className='fs-4'>Parent Reset</span>
                    </button>
                </div>
            </div>

            // <div>
            //     <h2 className="text-success text-center mt-5 mb-5">Calling Child Method from Parent using ref</h2>

            //     {/* <Counter interval={10} ref="t1"/>       Depricated */}

            //     {/* <Counter interval={10} ref={elem => { this.t1 = elem; }} /> */}

            //     <Counter interval={10} ref={this._counterRef} />

            //     <div className="d-grid gap-2 mx-auto col-6 mt-5">
            //         <button className="btn btn-warning" onClick={this.p_reset}>
            //             <span className='fs-4'>Parent Reset</span>
            //         </button>
            //     </div>
            // </div>

            // <div>
            //     <Counter />
            //     <br />
            //     <Counter interval={10} />
            // </div>
        );
    }
}

export default CounterAssignment;