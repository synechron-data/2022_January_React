// import React, { Component } from 'react';

// class DemoComponent extends Component {
//     render() {
//         return (
//             <div>
//                 <h2 className="text-info">Hello, {this.props.name.toUpperCase()}</h2>
//                 <h2 className="text-info">Age, {this.props.age}</h2>
//             </div>
//         );
//     }

//     static get defaultProps() {
//         return {
//             name: "Not Given",
//             age: 0
//         };
//     }
// }

// const PropTypesComponent = () => {
//     return (
//         <div>
//             <h2 className="text-primary text-center">Prop Types Demo</h2>
//             <DemoComponent />
//             <DemoComponent name={"Manish"} />
//             <DemoComponent name={"Manish"} age={10} />
//         </div>
//     );
// };

// export default PropTypesComponent;

// ---------------------------------------------------------------------------------------

import React, { Component } from 'react';
import PropTypes from 'prop-types';

class DemoComponent extends Component {
    render() {
        return (
            <div>
                <h2 className="text-info">Hello, {this.props.name.toUpperCase()}</h2>
                <h2 className="text-info">Age, {this.props.age}</h2>
            </div>
        );
    }

    static get propTypes() {
        return {
            name: PropTypes.string.isRequired,
            // age: PropTypes.number.isRequired
            age: function (props, propName, componentName) {
                if (props[propName] < 20) {
                    return new Error(
                        'Invalid prop `' + propName + '` supplied to' +
                        ' `' + componentName + '`. age must be greater than 20.'
                    );
                }
            }
        };
    }
}

const PropTypesComponent = () => {
    return (
        <div>
            <h2 className="text-primary text-center">Prop Types Demo</h2>
            {/* <DemoComponent /> */}
            {/* <DemoComponent name={"Manish"} /> */}
            <DemoComponent name={"Manish"} age={10} />
            {/* <DemoComponent name={"Manish"} age={"10"} /> */}
        </div>
    );
};

export default PropTypesComponent;