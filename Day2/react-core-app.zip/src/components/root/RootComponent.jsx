import React from 'react';
import ClassVsFunctionalComponent from '../1_class-vs-function/ClassVsFunctionalComponent';
import PropTypesComponent from '../2_props-types/PropTypesComponent';
import LCDemoComponent from '../3_lifecycle-demo/LCDemoComponent';
import EventComponent from '../4_synthetic-events/EventComponent';
import CounterAssignment from '../assignment/CounterAssignment';
import ControlledVsUncontrolledComponent from '../5_controlled-vs-uncontrolled/ControlledVsUncontrolledComponent';
import CalculatorAssignment from '../assignment/CalculatorAssignment';
import ListRoot from '../6_list/ListComponent';
import ContextAPIDemo from '../7_context-api/ContextAPIDemo';
import SiblingCommunicationUsingContext from '../7_context-api/SiblingCommunicationUsingContext';

const RootComponent = () => {
    return (
        <div className='container'>
            {/* <ClassVsFunctionalComponent /> */}
            {/* <PropTypesComponent /> */}
            {/* <LCDemoComponent /> */}
            {/* <EventComponent /> */}
            {/* <CounterAssignment /> */}
            {/* <ControlledVsUncontrolledComponent /> */}
            {/* <CalculatorAssignment /> */}
            {/* <ListRoot /> */}
            {/* <ContextAPIDemo /> */}
            <SiblingCommunicationUsingContext />
        </div>
    );
};

export default RootComponent;