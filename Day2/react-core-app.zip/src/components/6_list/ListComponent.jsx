import React, { Component } from 'react';
import PropTypes from 'prop-types';
import DataTable from '../common/DataTable';

const ListItem = ({ item }) => <li className="list-group-item">{item.name}</li>;

const ListComponent = ({ items, children }) => {
    var l_items = items.map((item, index) => {
        return <ListItem item={item} key={index} />;
    });

    return (
        <div>
            {children ? children : null}
            <ul className="list-group">
                {l_items}
            </ul>
        </div>
    );
}

ListComponent.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object).isRequired
};

class ListRoot extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [
                { id: 1, name: "Manish" },
                { id: 2, name: "Abhijeet" },
                { id: 3, name: "Ramakant" },
                { id: 4, name: "Subodh" },
                { id: 5, name: "Abhishek" }
            ]
        };
    }

    render() {
        return (
            <div>
                {/* <ListComponent items={this.state.employees}>
                    <h1 className='text-info'>
                        Employees List
                    </h1>
                </ListComponent> */}

                <DataTable items={this.state.employees}>
                    <h4 className="text-primary text-uppercase font-weight-bold">Employees Table</h4>
                </DataTable>
            </div>
        );
    }
}

export default ListRoot;