const initialState = {
    count: 0,
    productsData: { products: [], status: "", flag: false }
};

export default initialState;